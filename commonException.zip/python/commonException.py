from functools import wraps
from string import Template

class DataMatchingServiceException(Exception):
    pass

import logging
logger = logging.getLogger()
logger.setLevel(logging.ERROR)

def on_fail(message,another_details):
    def on_fail_dec(func):
        @wraps(func)
        def on_fail_wrapper(*args, **kw):

            try:
                return func(*args, **kw)
            except Exception as e:
                logger.error(e)
                temp = Template("""{ "status": "failure","error": { "message":" $message ,because of $occourAt "},"jobDetails": $other }""")
                if 'orig' in e.__dict__:
                    message_addon = str(e.__dict__['orig']).replace('"','').strip()
                    message_addon = message_addon.replace('\n','')
                else:
                    message_addon = str(e).replace('"','').strip()
                    message_addon = message_addon.replace('\n','')
                another_detail=str(another_details).replace("'", '"')
            raise DataMatchingServiceException(temp.substitute(message=message, occourAt=message_addon,other=another_detail))
        return on_fail_wrapper
    return on_fail_dec
