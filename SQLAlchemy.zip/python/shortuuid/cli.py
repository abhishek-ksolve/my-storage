from .main import uuid


def main():
    print(uuid())
